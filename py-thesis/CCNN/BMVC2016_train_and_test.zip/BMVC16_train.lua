----------------------------------------------------------------------
cmd = torch.CmdLine()
cmd:text()
cmd:text('SVHN Loss Function')
cmd:text()
cmd:text('Options:')
-- loss (only BCE tested):
cmd:option('-loss', 'bce', 'type of loss function to minimize: nll | mse | margin')
-- training:
cmd:option('-save', '.', 'subdirectory to save/log experiments in')
cmd:option('-plot', false, 'live plot')
cmd:option('-optimization', 'SGD', 'optimization method: SGD | ASGD | CG | LBFGS')
cmd:option('-learningRate', 3e-3, 'learning rate at t=0')
cmd:option('-batchSize', 128, 'mini-batch size (1 = pure stochastic)')
cmd:option('-weightDecay', 0, 'weight decay (SGD only)')
cmd:option('-momentum', 0.9, 'momentum (SGD only)')
cmd:option('-size', 9, 'patch size')
cmd:option('-startEpoch','1','starting epoch')
cmd:option('-endEpoch','14','ending epoch')
cmd:option('-chunk','24','chunk id')
cmd:text()
opt = cmd:parse(arg or {})

----------------------------------------------------------------------
epoch = opt.startEpoch
lastEpoch = opt.endEpoch

dofile '1_data.lua'
dofile '2_model.lua'

if tonumber(epoch) > 1 then
	model = torch.load('./NETS/CCNN/model_'..tonumber(epoch-1)..'.net', 'ascii')

else
	model = create_CCNN_model()
	-- Add sigmoid layer for BCE loss function
	model:add(cudnn.Sigmoid())
end

dofile '3_loss.lua'
dofile '4_train.lua'

print(model)
----------------------------------------------------------------------
print '==> training!'

print('Loading chunk '..opt.chunk)
--load_chunk(opt.chunk)	

dataset, labels, valids, samples, tot = load_memory_efficient_dataset('./DATASET/CCNN/',opt.chunk)

while true do

	-- Act here to change learning rate at a certain iteration 

	--if tonumber(epoch) == 11 then
	--	optimState.learningRate = optimState.learningRate / 10
	--end

	train()

	epoch = epoch + 1
	if tonumber(epoch) > tonumber(lastEpoch) then
		break
	end
end
