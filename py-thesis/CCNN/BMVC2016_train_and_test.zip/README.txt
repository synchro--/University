Training and testing code for paper "Learning from scratch a confidence measure", BMVC 2016.
If you use this code, please cite this paper:

M. Poggi, S. Mattoccia, “Learning from scratch a conﬁdence measure”, accepted at 27th British Machine Vision Conference (BMVC 2016), September 19-22, 2016, York, UK 

Bibtex:

@INPROCEEDINGS{CCNN_BMVC_2016,
   author = “Poggi, {M} and Mattoccia, {S}",
   title = "Learning from scratch a conﬁdence measure",
   booktitle = "27th British Machine Vision Conference (BMVC 2016)",
   month = Sep,
   year = 2016,
   day = “19-22”,
   address = “York, UK”,
}

For any further question, contact:
	matteo.poggi8@unibo.it

Hardware Requirements:
	Training: GPU with cuda capabilities > 3
	Testing: At least 4GB RAM for CPU testing, a 2GB GPU with cuda capabilities > 3 (the test requires about 2GB memory to run)

Software Requirements: 
	Linux
	Torch 7 (torch.ch)
	+cudnn
	*OpenCV 2.4.x (opencv.org)

Provided Tools:
	Training procedure (GPU required)
	Testing script on GPU
	Testing script on CPU
	Conversion tool (GPU model to CPU model)

Usage:
	Open a shell and compile merge utility by running `make` to enable 16 bit confidence encoding.
	
	To train CCNN:
		run `th 1_data.lua -first 0 -last X`. A training set will be created in ./DATASET/CCNN/,
		containing samples from KITTI image 000000 to 000X.
		Use -inputFolder to set the folder containing the disparity maps used to build the 			dataset. The script assumes they are inside a subfolder named after the image. Use 
		`-disparityName` to change the file name of the disparity maps. Use `-gtFolder` to change the
		folder where to find ground-truth disparity maps.
		e.g. The script assumes, by default, to find the disparity maps in ./ad/KITTI/, in particular in
		./ad/KITTI/000000/ he assumes to find the disparity map for image 000000, and he look for 
		ground-truth images in /KITTI/disp_noc/

		Run `th BMVC16_train.lua -chunk X -endepoch Y` to train the network on images 0-X for Y epochs.
		User `-firstEpoch` to set the initial epoch to Z (for incremental training)
	
	To test CCNN (GPU):
		Run `th BMVC16_test_gpu.lua`. Default parameters will depict the confidence map for the 
		provided disparity sample. Run `th BMVC16_test.lua -disparity X.png -output Y.png -enable16Bit
		'false'` if you want to run the demo on a different disparity map named X.png, saving the 
		confidence as Y.png. Setting -enable16Bit to 'false' will save confidence maps as 8 bit images
		(lower precision), but will not required OpenCV to be installed. Use `-model` to change the 
		network for confidence prediction (by default, it will use dummy.net from ./NETS/CCNN/. Note 
		that dummy.net is a little more accurate than the network used to provide results on our paper)

	To test CCNN (CPU):
		Run `th convert.lua` to convert a GPU trained model to CPU implementation.
		Use `-input` and `-output` flags to define both GPU and CPU file names.
		Run `th BMVC16_test_cpu.lua` to test on CPU, same usage as for GPU tests (by default, it will load
		cpu.net from ./NETS/CCNN/.)	


*OpenCV is required for 16-bit confidence maps
+cudnn is required for training, optional for testing if you convert the network with convert.lua 
