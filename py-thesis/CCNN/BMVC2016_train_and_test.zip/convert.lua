require 'cudnn'

if not opt then
   cmd = torch.CmdLine()
   cmd:text()
   cmd:text('Dataset Preprocessing')
   cmd:text()
   cmd:text('Options:')
   cmd:option('-input','./NETS/CCNN/dummy.net','input confidence map')
   cmd:option('-output','./NETS/CCNN/cpu.net','output name')
   cmd:text()
   opt = cmd:parse(arg or {})
end

gpu = torch.load(opt.input, 'ascii')
cpu = nn.Sequential()

for i=0,6 do
	ninput = gpu.modules[i*2+1].weight:size()[2]
	noutput = gpu.modules[i*2+1].weight:size()[1]
	k = gpu.modules[i*2+1].weight:size()[3]

	cpu:add(nn.SpatialConvolution(ninput, noutput, k, k))
	if i <6 then 
		cpu:add(nn.ReLU())
	else
		cpu:add(nn.Sigmoid())
	end

	cpu.modules[i*2+1].bias = gpu.modules[i*2+1].bias:float() 
	cpu.modules[i*2+1].weight = gpu.modules[i*2+1].weight:float() 
end

torch.save(opt.output, cpu, 'ascii')
print(cpu)
