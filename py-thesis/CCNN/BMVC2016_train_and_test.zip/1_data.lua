require 'torch'   -- torch
require 'image'   -- for color transforms
require 'gfx.js'  -- to visualize the dataset
require 'nn'      -- provides a normalization operator
require 'xlua'	  -- useful tools (progress bar)


----------------------------------------------------------------------
-- parse command line arguments
if not opt then
   print '==> processing options'
   cmd = torch.CmdLine()
   cmd:text()
   cmd:text('Dataset Preprocessing')
   cmd:text()
   cmd:text('Options:')
   cmd:option('-inputFolder', './ad/KITTI/', 'Input folder')
   cmd:option('-first', 0, 'First image')
   cmd:option('-last', 24, 'Last image')
   cmd:option('-disparityName', 'disparity_LR.png', 'File name for disparity maps')
   cmd:option('-datasetFolder', './DATASET/', 'dataset folder')
   cmd:option('-gtFolder', '/KITTI/disp_noc/', 'dataset folder')
   cmd:option('-size', 9, 'patch size')
   cmd:option('-createDataset', false, 'Creating dataset')
   cmd:text()
   opt = cmd:parse(arg or {})
end
----------------------------------------------------------------------

torch.setdefaulttensortype('torch.FloatTensor') -- preprocessing requires a floating point representation 

function load_memory_efficient_dataset(folder, id)
	local dataset = torch.load(folder..'dataset_'..id..'.th', dataset)
	print 'Dataset loaded!'
	local labels = torch.load(folder..'labels_'..id..'.th', labels)
	print 'Labels loaded!'
	local valids = torch.load(folder..'valids_'..id..'.th', valids)
	print 'Valid pixels loaded!'
	local samples = torch.load(folder..'samples_'..id..'.th', samples)
	local total_samples = 0
	for t = 1, #samples do
		total_samples = total_samples + samples[t]
	end
	print('Total samples: '..total_samples)
	return dataset, labels, valids, samples, total_samples
end

function create_confidence_dataset(first, last)

	local dataset = {}
	local tot_samples = 0
	local samples = {}
	local labels = {}
	local valids = {}
	--local corrects = 0;

	-- loading images 	
	for t = first, last do

		local image_id    
		if t < 10 then
			image_id = '00000'..t
		else
			image_id = '0000'..t
		end
			
		if t > 99 then
			image_id = '000'..t
		end

		gt = image.load(opt.gtFolder..image_id..'_10.png')
		local sample_size = 0
		
		label = torch.zeros(gt:size()[2], gt:size()[3], 1)
		valid =  torch.zeros(1, gt:size()[2], gt:size()[3])		
		sample = torch.zeros(1, gt:size()[2], gt:size()[3])

		disparity = image.load(opt.inputFolder..image_id..'/'..opt.disparityName):float()
		sample = disparity

		for i=1,gt:size()[2] do
			for j=1,gt:size()[3] do  
				if gt[1][i][j] ~= 0
				and i-math.floor(opt.size/2) > 0 
				and j-math.floor(opt.size/2) > 0 
				and i+math.floor(opt.size/2) <= gt:size()[2] 
				and j+math.floor(opt.size/2) <= gt:size()[3]
				then 
					sample_size = sample_size+1
					valid[1][i][j] = 1
					
					if math.abs(disparity[1][i][j] * 255.0 - gt[1][i][j] * 255.0) <= 3
					then
						label[i][j][1] = 1
					end
 				end
			end
		end
		tot_samples = tot_samples + sample_size

		
		table.insert(dataset, sample)
		table.insert(samples, sample_size)
		table.insert(labels, label)
		table.insert(valids, valid)
		
		print('Maps for '..image_id..' added to dataset!')
	end	
	return dataset, labels, valids, samples, tot_samples
end

function create_confidence_dataset_and_save(first, last, folder)
	os.execute('mkdir '..folder)
	dataset, labels, valids, samples, tot= create_confidence_dataset(first, last)
	torch.save(folder..'dataset_'..last..'.th', dataset)
	torch.save(folder..'labels_'..last..'.th', labels)
	torch.save(folder..'valids_'..last..'.th', valids)
	torch.save(folder..'samples_'..last..'.th', samples)
end

if opt.createDataset == true then
	create_confidence_dataset_and_save(opt.first, opt.last, opt.datasetFolder..'CCNN/')
end

