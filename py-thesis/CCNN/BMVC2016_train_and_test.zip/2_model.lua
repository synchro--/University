require 'torch'-- torch
require 'image'-- for image transforms
require 'nn'-- provides all sorts of trainable modules/layers
require 'cudnn'
require 'gfx.js'  -- provides visualization

-- parse command line arguments
if not opt then
print '==> processing options'
cmd = torch.CmdLine()
cmd:text()
cmd:text('SVHN convnet Definition')
cmd:text()
cmd:text('Options:')
cmd:option('-size', 9, 'patch size')
cmd:text()
opt = cmd:parse(arg or {})
end


function create_CCNN_model()	
	
	-- input-output dimensions
	nfeats = 1
	noutputs = 1

	-- convolutional kernels
	nstates = 64
	neurons = 100

	local model = nn.Sequential()
	mapSize = opt.size
	kernelSize = {3}
	stride = {1}	

	--------------------------
	-- CONVOLUTIONAL LAYERS --
	--------------------------
--------------------------------------	

	-- layer 1 
	-- convolution + ReLU
	model:add(cudnn.SpatialConvolution(nfeats, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	-----------------
	-- layer 2 
	-----------------
	model:add(cudnn.SpatialConvolution(nstates, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	-----------------
	-- layer 3+ 
	-----------------
	if opt.size > 5 then
	model:add(cudnn.SpatialConvolution(nstates, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	if opt.size > 7 then
	model:add(cudnn.SpatialConvolution(nstates, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	if opt.size > 9 then
	model:add(cudnn.SpatialConvolution(nstates, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	if opt.size > 11 then
	model:add(cudnn.SpatialConvolution(nstates, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	if opt.size > 13 then
	model:add(cudnn.SpatialConvolution(nstates, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	if opt.size > 15 then
	model:add(cudnn.SpatialConvolution(nstates, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	if opt.size > 17 then
	model:add(cudnn.SpatialConvolution(nstates, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	if opt.size > 19 then
	model:add(cudnn.SpatialConvolution(nstates, nstates, kernelSize[1], kernelSize[1], stride[1], stride[1]))
	model:add(cudnn.ReLU())

	end

	end
	end
	end
	end
	end
	end
	end
--------------------------------------
	--------------------------
	-- FULLY CONNECT LAYERS --
	--------------------------
--------------------------------------	

	-- fully connected 1
	model:add(cudnn.SpatialConvolution(nstates, neurons, 1, 1, stride[1], stride[1]))	
	model:add(cudnn.ReLU())

	-- fully connected 2
	model:add(cudnn.SpatialConvolution(neurons, neurons, 1,1 , stride[1], stride[1]))	
	model:add(cudnn.ReLU())

	-- Regression neuron
	model:add(cudnn.SpatialConvolution(neurons, 1, 1, 1, stride[1], stride[1]))	

	--------------------------
	-- RETURN --
	--------------------------
--------------------------------------	
	--torch.save('template.net', model, 'ascii')
	return model
end
