----------------------------------------------------------------------
-- This script demonstrates how to define a training procedure,
-- irrespective of the model/loss functions chosen.
--
-- It shows how to:
--   + construct mini-batches on the fly
--   + define a closure to estimate (a noisy) loss
--     function, as well as its derivatives wrt the parameters of the
--     model to be trained
--   + optimize the function, according to several optmization
--     methods: SGD, L-BFGS.
--
-- Clement Farabet
----------------------------------------------------------------------

require 'torch'   -- torch
require 'xlua'    -- xlua provides useful tools, like progress bars
require 'optim'   -- an optimization package, for online and batch methods

----------------------------------------------------------------------
-- parse command line arguments
if not opt then
   print '==> processing options'
   cmd = torch.CmdLine()
   cmd:text()
   cmd:text('SVHN Training/Optimization')
   cmd:text()
   cmd:text('Options:')
   cmd:option('-learningRate', 1e-3, 'learning rate at t=0')
   cmd:option('-batchSize', 1, 'mini-batch size (1 = pure stochastic)')
   cmd:option('-weightDecay', 0, 'weight decay (SGD only)')
   cmd:option('-momentum', 0, 'momentum (SGD only)')
   cmd:option('-size',9,'patches size')
   cmd:text()
   opt = cmd:parse(arg or {})
end

----------------------------------------------------------------------

model:cuda()
criterion:cuda()

----------------------------------------------------------------------

-- Retrieve parameters and gradients:
-- this extracts and flattens all the trainable parameters of the mode
-- into a 1-dim vector
if model then
   parameters,gradParameters = model:getParameters()
end

----------------------------------------------------------------------
-- SGD optim method
----------------------------------------------------------------------
   optimState = {
      learningRate = opt.learningRate,
      weightDecay = opt.weightDecay,
      momentum = opt.momentum,
      learningRateDecay = 1e-7
   }
   optimMethod = optim.sgd
----------------------------------------------------------------------

function train()

	-- epoch tracker
	epoch = epoch or 1
	steps = steps or 1
	corrects = 0

	-- local vars
	local time = sys.clock()

	-- set model to training mode (for modules that differ in training and testing, like Dropout)
	model:training()

	-- do one epoch
	print('==> doing epoch on training data:')
	print("==> online epoch # " .. epoch .. ' [batchSize = ' .. opt.batchSize .. ']')
	print('Learning rate: '..optimState.learningRate..', momentum: '..optimState.momentum)



	local processed = 0

	-- for each image in dataset
	for t = 1,#dataset do

		-- shuffle image at each epoch
		local shuffler_y = torch.randperm(dataset[t]:size()[2])
		local shuffler_x = torch.randperm(dataset[t]:size()[3])
	
		-- current pixel coords
		local i=0
		local j=0

		-- Processing image!!
		local p = 1
		local k = 1
		repeat
			xlua.progress(processed+k, tot)
			local inputs = {}
			local targets = {}

			-- create mini-batch
			repeat
				i = shuffler_y[math.ceil(p / dataset[t]:size()[3])]
				j = shuffler_x[(p % dataset[t]:size()[3]) + 1]

				if valids[t][1][i][j] ~= 0 
					and i-math.floor(opt.size/2) > 0 
					and j-math.floor(opt.size/2) > 0 
					and i+opt.size <= dataset[t]:size()[2] 
					and j+opt.size <= dataset[t]:size()[3]
				then

					local input = dataset[t]:narrow(2, i-math.floor(opt.size/2), opt.size):narrow(3, j-math.floor(opt.size/2), opt.size) 
					table.insert(inputs, input)
					table.insert(targets, labels[t][i][j])

					k = k+1
				end
				p = p + 1

			until #inputs == opt.batchSize or p == dataset[t]:size()[2] * dataset[t]:size()[3]

			if #inputs ~= 0 then
				-- create closure to evaluate f(X) and df/dX
				local feval = function(x)
					-- get new parameters
					if x ~= parameters 
					then
						parameters:copy(x)
					end

					-- reset gradients
					gradParameters:zero()

					-- f is the average of all criterions
					local f = 0

					tr_x = torch.CudaTensor(#inputs, inputs[1]:size()[1], inputs[1]:size()[2], inputs[1]:size()[3])
					tr_y = torch.CudaTensor(#targets, targets[1]:size()[1])

					for s=1,#inputs do
						tr_x[s] = inputs[s]
						tr_y[s] = targets[s]
					end

					-- evaluate function for complete mini batch
					output = model:forward(tr_x)

					local err = criterion:forward(output, tr_y)
					f = f + err
					df_do = criterion:backward(output, tr_y)
					model:backward(tr_x, df_do)
					steps = steps+1
				
					if (steps % 10 == 0) then
						local lossLog = io.open('loss.log', 'a')
						lossLog:write(steps..', '..f..'\n')
						lossLog:close()
					end
				
					-- return f and df/dX
					return f,gradParameters
				end

				-- optimize on current mini-batch
				if optimMethod == optim.asgd then
					_,_,average = optimMethod(feval, parameters, optimState)
				else
					optimMethod(feval, parameters, optimState)
				end
			end

		--end
		--until p >= samples[t]
		until p >= dataset[t]:size()[2] * dataset[t]:size()[3]
		processed = processed + samples[t]
	end

	print('Step: '..steps)
	filename='./NETS/CCNN/model_'..epoch..'.net'
	os.execute('mkdir -p ' .. sys.dirname(filename))
	print('==> saving model to '..filename)
	torch.save(filename, model,"ascii")
end
